package com.mycompany.act6;

/**
 *
 * @author Cortez Ramos
 */
public class Alumno {
    public String nombre;
    public Double[] calificacion = new Double[5];
}
